CHANDLER WALKER GAYTON FOUNDATION
Brand kit · Version 2.5 · October 2026
https://gaytonfoundation.org/brand/

WHAT IS IN THIS FOLDER

logos/
  cwgf-logo            Champagne #BE9A71. The main wordmark. Use on near-black
                       and on the dark ember gradient.
  cwgf-logo-on-light   Warm off-black #1A1814. Use on light backgrounds and for
                       print on white or cream paper.
  cwgf-logo-on-dark    White. Use on dark and purple backgrounds and for
                       reversed-out print.
  cwgf-logo-husky      UW Husky Purple #32006E. Use on light backgrounds in
                       purple-led event pieces.
  cwgf-logo-currentcolor.svg
                       For web developers. Takes the text color of its parent
                       when the SVG code is pasted inline.

  Each color comes in three file types:
  .svg   Vector. Scales to any size. Best for websites, sign shops, embroidery.
  .png   2000 px wide, transparent background. Best for documents and slides.
  .pdf   Vector. Best for print shops.

design-system/   (full kit only)
  CWGF-Brand-Design-System-Light.pdf   Foundation edition. The light look used
                                       on gaytonfoundation.org.
  CWGF-Brand-Design-System-Dark.pdf    Event edition. The dark look used for
                                       Boots on the Ground.
  The two .md files are plain text copies of the same rules. Hand one to an AI
  assistant so it follows the brand.

USING THE WORDMARK

  Clear space    Leave room equal to the height of the letter C in CHANDLER on
                 every side.
  Smallest size  1.1 in (105 px) wide in print, 140 px wide on screen.
  Please do not  stretch or squash it, recolor it outside the four colors here,
                 add shadows, glows or outlines, set it on a busy photo, retype
                 the name as a logo, or rotate it.

QUESTIONS

  joshua@gaytonfoundation.org
